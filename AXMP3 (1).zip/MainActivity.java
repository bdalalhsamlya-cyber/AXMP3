package com.example.musicplayer; // استبدل هذا بحزمة مشروعك الحقيقية

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnPlayPause, btnStop;
    private TextView txtTitle;
    private MediaPlayer mediaPlayer;
    private boolean isPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPlayPause = findViewById(R.id.btnPlayPause);
        btnStop = findViewById(R.id.btnStop);
        txtTitle = findViewById(R.id.txtTitle);

        // تهيئة الـ MediaPlayer (يمكنك وضع ملف صوتي بصيغة mp3 داخل مجلد raw أو رابط مباشر)
        // كمثال سنستخدم ملفاً افتراضياً من مجلد الـ raw (تأكد من إضافة ملف باسم song.mp3 في res/raw)
        mediaPlayer = MediaPlayer.create(this, R.raw.song);

        btnPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPlaying) {
                    // إيقاف مؤقت
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                    }
                    btnPlayPause.setText("تشغيل");
                    isPlaying = false;
                } else {
                    // تشغيل
                    mediaPlayer.start();
                    btnPlayPause.setText("إيقاف مؤقت");
                    isPlaying = true;
                }
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                    try {
                        mediaPlayer.prepare();
                        mediaPlayer.seekTo(0);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    btnPlayPause.setText("تشغيل");
                    isPlaying = false;
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}